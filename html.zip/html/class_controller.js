var class_controller =
[
    [ "Controller", "class_controller.html#a1e6ebd77b7bc513665c545081b006114", null ],
    [ "pid", "class_controller.html#a5ca89f4ad1f476446e01eebc8af0bd95", null ],
    [ "D_control", "class_controller.html#acfa94f3777e8cb527975b5120d82a10e", null ],
    [ "I_control", "class_controller.html#ad4a8575e7b9468d3d7d04f63b054a326", null ],
    [ "Kd", "class_controller.html#af7e83005867a4090ac7e9d43b4eb3849", null ],
    [ "Ki", "class_controller.html#ac231eb98402bf240007d7ed815ed5603", null ],
    [ "Kp", "class_controller.html#a5fd3d0cbde86404b2a4bed4269f55201", null ],
    [ "P_control", "class_controller.html#a85e5d432ccea51796cd4c282f702d048", null ],
    [ "pre_error", "class_controller.html#a9abe90803e43461ca301f7f76181f3cc", null ]
];