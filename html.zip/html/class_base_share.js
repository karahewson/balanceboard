var class_base_share =
[
    [ "BaseShare", "class_base_share.html#a73741a4ad0b9b54f6f6da20855c2e30b", null ],
    [ "print_in_list", "class_base_share.html#a6f72027a717afada4679fd08d08bb4b6", null ],
    [ "print_all_shares", "class_base_share.html#a4700b5f4d08a994556955c2aa75f3236", null ],
    [ "name", "class_base_share.html#abc438f82d56097f13a1e791dcd617a72", null ],
    [ "p_next", "class_base_share.html#a8077022ea40c4ba44a6ff07ab24cac83", null ]
];