var main_8cpp =
[
    [ "loop", "main_8cpp.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "main_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "task_sim", "main_8cpp.html#aedae232608142fbbd4ece4cfe363e74c", null ],
    [ "angle", "main_8cpp.html#adb06871b698978281e4e13038856bc90", null ]
];