var searchData=
[
  ['baseshare_50',['BaseShare',['../class_base_share.html',1,'']]]
];
