var searchData=
[
  ['setup_42',['setup',['../main_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d',1,'main.cpp']]],
  ['share_43',['Share',['../class_share.html',1,'Share&lt; DataType &gt;'],['../class_share.html#a0948b04d00aef072f25af2f49ecfa259',1,'Share::Share()']]]
];
