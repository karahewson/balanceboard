var searchData=
[
  ['max_5ffull_97',['max_full',['../class_queue.html#acd5a036b50ef0fc8f1e587bb7307cee4',1,'Queue']]]
];
