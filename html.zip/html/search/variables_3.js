var searchData=
[
  ['handle_93',['handle',['../class_queue.html#a69b90b10718e9469499375c61cc9c236',1,'Queue']]]
];
