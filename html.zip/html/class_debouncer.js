var class_debouncer =
[
    [ "Debouncer", "class_debouncer.html#a56d8627529d52fa7051cc542ee48186a", null ],
    [ "update", "class_debouncer.html#ac91bbb4b042ca7939897c49587d035d8", null ],
    [ "count", "class_debouncer.html#a9a561331885653c3afa5baed95d4c81d", null ],
    [ "pin", "class_debouncer.html#aa805fd0ce5b002dd91e95fe1c8f44970", null ],
    [ "state", "class_debouncer.html#a50b7f921222452bf7328ad84d09c15af", null ],
    [ "threshold", "class_debouncer.html#a89451b7174f5f6e425f89ea91220a487", null ],
    [ "triggered", "class_debouncer.html#a929874ffbf8746eb8dceb830e2dce1e6", null ]
];