var files_dup =
[
    [ "baseshare.cpp", "baseshare_8cpp.html", "baseshare_8cpp" ],
    [ "baseshare.h", "baseshare_8h.html", "baseshare_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "motor.cpp", "motor_8cpp.html", "motor_8cpp" ],
    [ "motor.h", "motor_8h.html", [
      [ "Controller", "class_controller.html", "class_controller" ]
    ] ],
    [ "mpu6050.h", "mpu6050_8h_source.html", null ],
    [ "task_inclinometer.h", "task__inclinometer_8h_source.html", null ],
    [ "taskqueue.h", "taskqueue_8h.html", [
      [ "Queue", "class_queue.html", "class_queue" ]
    ] ],
    [ "taskshare.h", "taskshare_8h.html", [
      [ "Share", "class_share.html", "class_share" ]
    ] ]
];