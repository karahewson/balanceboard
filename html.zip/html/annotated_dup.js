var annotated_dup =
[
    [ "BaseShare", "class_base_share.html", "class_base_share" ],
    [ "Controller", "class_controller.html", "class_controller" ],
    [ "MPU6050", "class_m_p_u6050.html", "class_m_p_u6050" ],
    [ "Queue", "class_queue.html", "class_queue" ],
    [ "Share", "class_share.html", "class_share" ]
];